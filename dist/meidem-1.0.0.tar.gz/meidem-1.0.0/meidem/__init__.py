"""
MEIDEM — Multi-grid Exoplanet Interpolator for limb DarkEning Models
=====================================================================
API pública unificada para interpolação de coeficientes de limb darkening
a partir de múltiplas grades da literatura.

Grades suportadas
-----------------
  'kostogryz2022' : Kostogryz+2022, MPS-ATLAS
                    Leis: 'nonlinear' (4coeff), 'power2'
                    Passbands: TESS, Kepler, CHEOPS, PLATO

  'claret2022'    : Claret & Southworth 2022, A&A 664, A128
                    Leis: 'power2'
                    Passbands: TESS, Kepler, Gaia_G, Gaia_BP, Gaia_RP,
                               SDSS_u, SDSS_g, SDSS_r, SDSS_i, SDSS_z,
                               uvby, Johnson_U/B/V/R/I, 2MASS_J/H/K

  'claret2017'    : Claret 2017, A&A 600, A30
                    Leis: 'quadratic', 'square-root', 'logarithmic',
                           '4coeff', 'linear', 'y'
                    Passbands: TESS
                    Modelos: ATLAS (mod='A'), PHOENIX (mod='P')

  'claret2011'    : Claret & Bloemen 2011, A&A 529, A75
                    Leis: 'quadratic', 'root-square', 'logarithmic',
                           '4coeff', 'linear', 'y'
                    Passbands: Kepler (Kp), CoRoT (C), Spitzer (S1, S2)
                    Modelos: ATLAS (mod='A'), PHOENIX (mod='P')

Uso rápido
----------
>>> import meidem
>>> result = meidem.get_ld_coefficients(
...     teff=5778, logg=4.44, feh=0.0,
...     passband='TESS',
...     grid='kostogryz2022',
...     law='power2',
... )
>>> print(result['coefficients'])

>>> # Listar grades e leis disponíveis
>>> meidem.available_grids()
>>> meidem.available_laws('claret2017')
>>> meidem.available_passbands('claret2022')
"""

from ._version import __version__
from .grids.kostogryz2022 import KostogryzGrid
from .grids.claret2022    import Claret2022Grid
from .grids.claret2017    import Claret2017Grid
from .grids.claret2011    import Claret2011Grid

__all__ = [
    '__version__',
    'get_ld_coefficients',
    'available_grids',
    'available_laws',
    'available_passbands',
]

# ── Registro de grades ────────────────────────────────────────────────────────

_GRIDS = {
    'kostogryz2022': {
        'class'     : KostogryzGrid,
        'reference' : 'Kostogryz et al. (2022)',
        'model'     : 'MPS-ATLAS',
        'laws'      : ['nonlinear', 'power2'],
        'passbands' : ['TESS', 'Kepler', 'CHEOPS', 'PLATO'],
        'doi'       : '10.1051/0004-6361/202140376',
    },
    'claret2022': {
        'class'     : Claret2022Grid,
        'reference' : 'Claret & Southworth (2022), A&A 664, A128',
        'model'     : 'ATLAS',
        'laws'      : ['power2'],
        'passbands' : ['TESS', 'Kepler', 'Gaia_G', 'Gaia_BP', 'Gaia_RP',
                       'SDSS_u', 'SDSS_g', 'SDSS_r', 'SDSS_i', 'SDSS_z',
                       'Johnson_U', 'Johnson_B', 'Johnson_V', 'Johnson_R', 'Johnson_I',
                       '2MASS_J', '2MASS_H', '2MASS_K'],
        'doi'       : '10.1051/0004-6361/202244278',
    },
    'claret2017': {
        'class'     : Claret2017Grid,
        'reference' : 'Claret (2017), A&A 600, A30',
        'model'     : 'ATLAS/PHOENIX',
        'laws'      : ['quadratic', 'square-root', 'logarithmic', '4coeff', 'linear', 'y'],
        'passbands' : ['TESS'],
        'doi'       : '10.1051/0004-6361/201629705',
    },
    'claret2011': {
        'class'     : Claret2011Grid,
        'reference' : 'Claret & Bloemen (2011), A&A 529, A75',
        'model'     : 'ATLAS/PHOENIX',
        'laws'      : ['quadratic', 'root-square', 'logarithmic', '4coeff', 'linear', 'y'],
        'passbands' : ['Kp', 'C', 'S1', 'S2'],
        'doi'       : '10.1051/0004-6361/201116451',
    },
}

# ── API principal ─────────────────────────────────────────────────────────────

def get_ld_coefficients(
    teff,
    logg,
    feh,
    passband,
    grid        = 'kostogryz2022',
    law         = None,
    xi          = 2.0,
    met         = 'L',
    mod         = 'A',
    verbose     = False,
):
    """
    Interpola coeficientes de limb darkening a partir de grades da literatura.

    Parâmetros
    ----------
    teff     : float
        Temperatura efetiva da estrela (K).
    logg     : float
        Gravidade superficial log g (cgs).
    feh      : float
        Metalicidade [Fe/H] (dex).
    passband : str
        Banda fotométrica. Depende da grade escolhida.
        Ex: 'TESS', 'Kepler', 'Gaia_G', 'Kp', 'C'
    grid     : str, optional
        Grade de coeficientes. Default: 'kostogryz2022'.
        Opções: 'kostogryz2022', 'claret2022', 'claret2017', 'claret2011'
    law      : str or None, optional
        Lei de limb darkening. Se None, usa o default da grade:
          - kostogryz2022 → 'power2'
          - claret2022    → 'power2'
          - claret2017    → 'quadratic'
          - claret2011    → 'quadratic'
    xi       : float, optional
        Microturbulência em km/s (só ATLAS). Default: 2.0.
        Valores disponíveis: 0, 1, 2, 4, 8.
    met      : str, optional
        Método de ajuste (só Claret 2017/2011).
        'L' = Least-Squares (default) | 'F' = Flux Conservation
    mod      : str, optional
        Modelo de atmosfera (só Claret 2017/2011).
        'A' = ATLAS (default) | 'P' = PHOENIX
    verbose  : bool, optional
        Se True, imprime informações da grade e coeficientes. Default: False.

    Retorno
    -------
    dict com chaves:
        'coefficients' : list[float]  — coeficientes interpolados
        'n_coeffs'     : int          — número de coeficientes
        'law'          : str          — lei de LD usada
        'passband'     : str          — passband usada
        'grid'         : str          — grade usada
        'reference'    : str          — citação bibliográfica
        'doi'          : str          — DOI do artigo
        'teff_input'   : float        — Teff fornecida
        'logg_input'   : float        — logg fornecido
        'feh_input'    : float        — [Fe/H] fornecido
        'xi'           : float|None   — microturbulência (None se PHOENIX)
        'met'          : str|None     — método (None se não aplicável)
        'mod'          : str|None     — modelo (None se não aplicável)

    Exemplos
    --------
    >>> import meidem

    >>> # Kostogryz+2022 — power-2 para TESS
    >>> r = meidem.get_ld_coefficients(5778, 4.44, 0.0, 'TESS', grid='kostogryz2022', law='power2')
    >>> r['coefficients']
    [0.412, 0.631]

    >>> # Claret & Southworth 2022 — power-2 para Kepler
    >>> r = meidem.get_ld_coefficients(5778, 4.44, 0.0, 'Kepler', grid='claret2022')
    >>> r['coefficients']
    [0.398, 0.618]

    >>> # Claret 2017 — quadratic para TESS, ATLAS, Least-Squares
    >>> r = meidem.get_ld_coefficients(5778, 4.44, 0.0, 'TESS',
    ...     grid='claret2017', law='quadratic', mod='A', met='L')
    >>> r['coefficients']
    [0.321, 0.287]

    >>> # Claret & Bloemen 2011 — quadratic para Kepler
    >>> r = meidem.get_ld_coefficients(5778, 4.44, 0.0, 'Kp',
    ...     grid='claret2011', law='quadratic')
    >>> r['coefficients']
    [0.415, 0.295]

    Raises
    ------
    ValueError
        Se a grade, lei ou passband não forem suportadas, ou se os parâmetros
        estelares estiverem fora dos limites da grade.
    """
    # ── Valida grade ──────────────────────────────────────────
    grid = grid.lower()
    if grid not in _GRIDS:
        raise ValueError(
            f"Grade '{grid}' não suportada.\n"
            f"Opções disponíveis: {list(_GRIDS.keys())}\n"
            f"Use meidem.available_grids() para ver detalhes."
        )

    grid_info = _GRIDS[grid]

    # ── Default de lei por grade ──────────────────────────────
    _default_law = {
        'kostogryz2022': 'power2',
        'claret2022'   : 'power2',
        'claret2017'   : 'quadratic',
        'claret2011'   : 'quadratic',
    }
    if law is None:
        law = _default_law[grid]

    # ── Instancia interpolador e obtém coeficientes ───────────
    InterpolatorClass = grid_info['class']

    # Argumentos comuns a todas as grades
    common_kwargs = dict(teff=teff, logg=logg, feh=feh, verbose=verbose)

    if grid == 'kostogryz2022':
        coeffs, meta = InterpolatorClass.interpolate(
            passband=passband, law=law, **common_kwargs)
    elif grid == 'claret2022':
        coeffs, meta = InterpolatorClass.interpolate(
            passband=passband, xi=xi, **common_kwargs)
    elif grid == 'claret2017':
        coeffs, meta = InterpolatorClass.interpolate(
            passband=passband, law=law, xi=xi, met=met, mod=mod, **common_kwargs)
    elif grid == 'claret2011':
        coeffs, meta = InterpolatorClass.interpolate(
            passband=passband, law=law, xi=xi, met=met, mod=mod, **common_kwargs)

    # ── Monta retorno padronizado ─────────────────────────────
    return {
        'coefficients': coeffs,
        'n_coeffs'    : len(coeffs),
        'law'         : law,
        'passband'    : passband,
        'grid'        : grid,
        'reference'   : grid_info['reference'],
        'doi'         : grid_info['doi'],
        'teff_input'  : teff,
        'logg_input'  : logg,
        'feh_input'   : feh,
        'xi'          : xi if grid in ('claret2017', 'claret2011') and mod == 'A' else None,
        'met'         : met if grid in ('claret2017', 'claret2011') else None,
        'mod'         : mod if grid in ('claret2017', 'claret2011') else None,
    }


# ── Funções de descoberta ─────────────────────────────────────────────────────

def available_grids(verbose=True):
    """
    Lista todas as grades de LD disponíveis no MEIDEM.

    Retorno
    -------
    list[str] — nomes das grades disponíveis
    """
    if verbose:
        print("=" * 65)
        print("MEIDEM — Grades de Limb Darkening disponíveis")
        print("=" * 65)
        for name, info in _GRIDS.items():
            print(f"\n  [{name}]")
            print(f"    Referência : {info['reference']}")
            print(f"    Modelo     : {info['model']}")
            print(f"    Leis       : {info['laws']}")
            print(f"    Passbands  : {info['passbands']}")
            print(f"    DOI        : {info['doi']}")
        print("=" * 65)
    return list(_GRIDS.keys())


def available_laws(grid, verbose=True):
    """
    Lista as leis de LD disponíveis para uma grade específica.

    Parâmetros
    ----------
    grid : str — nome da grade

    Retorno
    -------
    list[str]
    """
    grid = grid.lower()
    if grid not in _GRIDS:
        raise ValueError(f"Grade '{grid}' não encontrada. Use available_grids().")
    laws = _GRIDS[grid]['laws']
    if verbose:
        print(f"Leis disponíveis para '{grid}': {laws}")
    return laws


def available_passbands(grid, verbose=True):
    """
    Lista as passbands disponíveis para uma grade específica.

    Parâmetros
    ----------
    grid : str — nome da grade

    Retorno
    -------
    list[str]
    """
    grid = grid.lower()
    if grid not in _GRIDS:
        raise ValueError(f"Grade '{grid}' não encontrada. Use available_grids().")
    passbands = _GRIDS[grid]['passbands']
    if verbose:
        print(f"Passbands disponíveis para '{grid}': {passbands}")
    return passbands